import { NgModule, ErrorHandler } from '@angular/core';
import { IonicApp, IonicModule, IonicErrorHandler } from 'ionic-angular';
import { RouterModule, Routes } from '@angular/router';

import { MyApp } from './app.component';
import { HomePage } from './../pages/home/home';
import { Signup } from './../pages/signup/signup';

const appRoutes: Routes = [
  { path: 'signin', component: HomePage },
  { path: 'signup', component: Signup },
];

@NgModule({
  declarations: [
    MyApp,
    HomePage,
    Signup
  ],
  imports: [
    RouterModule.forRoot(appRoutes),
    IonicModule.forRoot(MyApp)
  ],
  bootstrap: [IonicApp],
  entryComponents: [
    MyApp,
    HomePage,
    Signup
  ],
  providers: [{provide: ErrorHandler, useClass: IonicErrorHandler}]
})
export class AppModule {}
